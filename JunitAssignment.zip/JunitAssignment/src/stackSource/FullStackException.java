
package stackSource;

public class FullStackException extends Exception{
    public FullStackException(){
        System.out.print("The stack is full!");
    }
    
}
