
package stackSource;

public class Item {
    int number;

    public Item() {
       number = 4;
    }
    
    public Item(int number){
        this.number = number;
    }
    
}
