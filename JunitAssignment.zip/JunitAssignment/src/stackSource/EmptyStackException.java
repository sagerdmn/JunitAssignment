
package stackSource;

class EmptyStackException extends Exception {

    public EmptyStackException(){
        System.out.print("The stack is empty!");
    } 
}
